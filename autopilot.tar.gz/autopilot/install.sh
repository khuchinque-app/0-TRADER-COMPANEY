#!/usr/bin/env bash
# Run as the khuchinque user (never via su from root).
set -e
AP="$(cd "$(dirname "$0")" && pwd)"
mkdir -p ~/.config/systemd/user
[ -f ~/.config/autopilot.env ] || cat > ~/.config/autopilot.env <<EOT
# AP_REPO=/home/khuchinque/0-TRADER-COMPANEY
# TG_TOKEN=
# TG_CHAT=
EOT
sed "s#__AP__#$AP#g" "$AP/autopilot.service" > ~/.config/systemd/user/autopilot.service
export XDG_RUNTIME_DIR=/run/user/$(id -u)
systemctl --user daemon-reload
systemctl --user enable --now autopilot.service
echo "started. follow: journalctl --user -u autopilot -f   |   status: cat $AP/TASKS.md   |   stop: touch $AP/STOP"
echo "If it dies on logout: loginctl enable-linger $USER (needs root once), or run inside tmux instead."
