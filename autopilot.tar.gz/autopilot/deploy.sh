#!/usr/bin/env bash
# Make the live services reflect the working tree before verify runs.
set -e
cd "${AP_REPO:-.}"

mode=$(pm2 jlist 2>/dev/null | python3 -c 'import sys,json
try:
  for p in json.load(sys.stdin):
    if p.get("name")=="terminal":
      e=p.get("pm2_env",{}); print(str(e.get("pm_exec_path",""))+" "+str(e.get("args","")))
except Exception: pass')

# Only rebuild when terminal runs a production build (never build under a running `next dev`).
case "$mode" in
  *" dev"*|*"dev "*|*"run dev"*) : ;;
  *) if [ -f apps/terminal/.next/BUILD_ID ]; then (cd apps/terminal && npm run build >/tmp/ap_build.log 2>&1 || { tail -40 /tmp/ap_build.log; exit 1; }); fi ;;
esac

pm2 restart backend terminal >/dev/null 2>&1 || true

wait_port() { for i in $(seq 1 30); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 2; done; echo "NOT UP: $1"; return 1; }
wait_port http://127.0.0.1:11110/
wait_port http://127.0.0.1:22220/
