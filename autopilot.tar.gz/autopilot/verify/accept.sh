#!/usr/bin/env bash
# Final goal gate: every task verify + smoke, against the live services.
set -uo pipefail
cd "${AP_REPO:-.}"
fail=0
for p in 11110 22220; do
  curl -s -o /dev/null -m 5 "http://127.0.0.1:$p/" || { echo "FAIL: port $p down"; fail=1; }
done
for v in autopilot/verify/T*.sh; do
  tmp=$(mktemp)
  if bash "$v" >"$tmp" 2>&1; then echo "PASS $(basename "$v")"; else echo "FAIL $(basename "$v")"; tail -15 "$tmp"; fail=1; fi
  rm -f "$tmp"
done
if bash autopilot/verify/gate_smoke.sh >/tmp/ap_smoke.out 2>&1; then echo "PASS smoke"; else echo "FAIL smoke"; tail -15 /tmp/ap_smoke.out; fail=1; fi
[ "$fail" = 0 ] && echo "ACCEPT OK" || echo "ACCEPT FAILED"
exit $fail
