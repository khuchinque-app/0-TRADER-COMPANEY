#!/usr/bin/env bash
set -uo pipefail
cd "${AP_REPO:-.}"
f=$(ls scripts/*smoke* 2>/dev/null | head -1)
[ -n "$f" ] || { echo "no scripts/*smoke* found - T03 must create scripts/smoke.sh"; exit 1; }
echo "running $f"
bash "$f"
