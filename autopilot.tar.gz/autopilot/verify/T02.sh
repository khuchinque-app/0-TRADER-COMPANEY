#!/usr/bin/env bash
# Unknown pair must render "Pair Not Found" in server HTML; a valid pair must not.
set -uo pipefail
T=${TERMINAL_URL:-http://127.0.0.1:22220}
body=$(curl -s -m 15 "$T/trade/FAKEXYZ") || { echo "terminal unreachable"; exit 1; }
echo "$body" | grep -qiE "pair not found|not found" || { echo "FAIL: /trade/FAKEXYZ has no 'not found' text in server HTML"; exit 1; }
echo "$body" | grep -qi "loading\.\.\." && ! echo "$body" | grep -qiE "pair not found" && { echo "FAIL: still stuck on Loading"; exit 1; }
# a real pair must not say not-found (try common spellings of the BTC pair)
ok=0
for p in BTCUSDT BTC-USDT btc_usdt BTC_USDT btcusdt BTCUSDT; do
  code=$(curl -s -o /tmp/ap_t02.html -w "%{http_code}" -m 15 "$T/trade/$p")
  if [ "$code" = "200" ] && ! grep -qiE "pair not found" /tmp/ap_t02.html; then ok=1; break; fi
done
[ "$ok" = 1 ] || { echo "FAIL: no valid BTC pair route returned 200 without 'not found'"; exit 1; }
echo "T02 OK"
